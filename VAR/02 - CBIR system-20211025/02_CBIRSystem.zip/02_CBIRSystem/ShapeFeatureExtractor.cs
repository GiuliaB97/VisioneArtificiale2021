﻿using Emgu.CV;
using Emgu.CV.Structure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_CBIRSystem
{
    public class ShapeFeatureExtractor
    {
        public ShapeFeatureExtractor()
        {

        }

        public Image<Gray, byte>[] ComputeDescriptors(Image<Bgr, byte>[] images)
        {
            var res = new Image<Gray, byte>[images.Length];
            for (int i = 0; i < images.Length; i++)
            {
                res[i] = ComputeDescriptor(images[i].Convert<Gray, byte>());
            }
            return res;
        }
        //int imgIdx = 0;

        public Image<Gray, byte> ComputeDescriptor(Image<Gray, byte> img)
        {
            throw new NotImplementedException();

            // var gx = Calcolo gradiente in x

            // var gy = Calcolo gradiente in y

            // var gMod = Calcolo modulo gradiente

            // var gModBinary = ... Resize e binarizzazione di gMod

            // var gModFinal = gModBinary.Dilate(3).Erode(3);   // Dilatazione + Erosione

            //return gModFinal;
        }
    }
}
