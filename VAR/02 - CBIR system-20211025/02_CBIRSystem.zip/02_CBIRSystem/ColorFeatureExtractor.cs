﻿using Emgu.CV;
using Emgu.CV.Structure;
using System;

namespace _02_CBIRSystem
{
    public class ColorFeatureExtractor
    {
        private int binCount = 20;
        public ColorFeatureExtractor()
        {

        }

        public float[] ComputeDescriptor(Image<Bgr, byte> img)
        {
            throw new NotImplementedException();   
        }

        public float[][] ComputeDescriptors(Image<Bgr, byte>[] images)
        {
            var res = new float[images.Length][];
            for (int i = 0; i < images.Length; i++)
            {
                res[i] = ComputeDescriptor(images[i]);
            }
            return res;
        }
    }
}
